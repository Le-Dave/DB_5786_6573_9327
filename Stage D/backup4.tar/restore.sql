--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.1 (Debian 17.1-1.pgdg120+1)
-- Dumped by pg_dump version 17.1 (Debian 17.1-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DB5786David";
--
-- Name: DB5786David; Type: DATABASE; Schema: -; Owner: MyUser
--

CREATE DATABASE "DB5786David" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "DB5786David" OWNER TO "MyUser";

\connect "DB5786David"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fn_get_chef_preparations(integer); Type: FUNCTION; Schema: public; Owner: MyUser
--

CREATE FUNCTION public.fn_get_chef_preparations(p_chef_id integer) RETURNS refcursor
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_exists BOOLEAN;
    v_cursor refcursor := 'chef_prep_cursor';   -- named ref cursor
BEGIN
    -- EXCEPTION : the chef does not exist
    SELECT EXISTS (SELECT 1 FROM chef WHERE chef_id = p_chef_id) INTO v_exists;
    IF NOT v_exists THEN
        RAISE EXCEPTION 'Chef % does not exist', p_chef_id;
    END IF;

    -- open the ref cursor over the chef's preparations
    OPEN v_cursor FOR
        SELECT f.log_id,
               mi.item_name,
               f.preparation_time,
               f.prep_date
        FROM   food_prep_log f
        JOIN   menu_item mi ON mi.menu_item_id = f.menu_item_id
        WHERE  f.chef_id = p_chef_id
        ORDER  BY f.prep_date DESC;

    RETURN v_cursor;
END;
$$;


ALTER FUNCTION public.fn_get_chef_preparations(p_chef_id integer) OWNER TO "MyUser";

--
-- Name: fn_menu_item_kitchen_stats(integer); Type: FUNCTION; Schema: public; Owner: MyUser
--

CREATE FUNCTION public.fn_menu_item_kitchen_stats(p_menu_item_id integer) RETURNS TABLE(item_name character varying, category_name character varying, price numeric, times_prepared integer, avg_prep_time numeric, popularity_label text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec     RECORD;        -- record variable
    v_label TEXT;
BEGIN
    -- implicit cursor (SELECT INTO) joining menu + kitchen
    SELECT mi.item_name        AS item_name,
           mc.category_name     AS category_name,
           mi.price             AS price,
           mi.times_prepared    AS times_prepared,
           ROUND(AVG(f.preparation_time), 1) AS avg_pt
    INTO rec
    FROM   menu_item mi
    JOIN   menu_category mc ON mi.category_id = mc.category_id
    LEFT JOIN food_prep_log f ON f.menu_item_id = mi.menu_item_id
    WHERE  mi.menu_item_id = p_menu_item_id
    GROUP BY mi.item_name, mc.category_name, mi.price, mi.times_prepared;

    -- EXCEPTION : the menu item does not exist
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Menu item % does not exist', p_menu_item_id;
    END IF;

    -- branching : popularity classification based on the kitchen counter
    IF rec.times_prepared = 0 THEN
        v_label := 'Never prepared';
    ELSIF rec.times_prepared < 100 THEN
        v_label := 'Low';
    ELSIF rec.times_prepared < 200 THEN
        v_label := 'Medium';
    ELSE
        v_label := 'High';
    END IF;

    RETURN QUERY
        SELECT rec.item_name, rec.category_name, rec.price,
               rec.times_prepared, rec.avg_pt, v_label;
END;
$$;


ALTER FUNCTION public.fn_menu_item_kitchen_stats(p_menu_item_id integer) OWNER TO "MyUser";

--
-- Name: sp_apply_category_price_increase(integer, numeric); Type: PROCEDURE; Schema: public; Owner: MyUser
--

CREATE PROCEDURE public.sp_apply_category_price_increase(IN p_category_id integer, IN p_percent numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_cat_name VARCHAR;
    v_count    INTEGER;
BEGIN
    -- validation + EXCEPTION
    IF p_percent <= 0 OR p_percent > 100 THEN
        RAISE EXCEPTION 'Invalid percent %, must be between 0 and 100', p_percent;
    END IF;

    SELECT category_name INTO v_cat_name
    FROM   menu_category
    WHERE  category_id = p_category_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Category % does not exist', p_category_id;
    END IF;

    -- DML : update the prices
    UPDATE menu_item
    SET    price = ROUND(price * (1 + p_percent / 100.0), 2)
    WHERE  category_id = p_category_id;

    GET DIAGNOSTICS v_count = ROW_COUNT;

    RAISE NOTICE 'Applied % percent increase to % item(s) in category "%"',
                 p_percent, v_count, v_cat_name;
END;
$$;


ALTER PROCEDURE public.sp_apply_category_price_increase(IN p_category_id integer, IN p_percent numeric) OWNER TO "MyUser";

--
-- Name: sp_archive_old_prep_logs(date); Type: PROCEDURE; Schema: public; Owner: MyUser
--

CREATE PROCEDURE public.sp_archive_old_prep_logs(IN p_cutoff_date date)
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- explicit cursor (FOR UPDATE allows DELETE WHERE CURRENT OF)
    cur_old CURSOR FOR
        SELECT log_id, menu_item_id, prep_date
        FROM   food_prep_log
        WHERE  prep_date < p_cutoff_date
        FOR UPDATE;
    rec       RECORD;
    v_deleted INTEGER := 0;
BEGIN
    -- validation + EXCEPTION
    IF p_cutoff_date > CURRENT_DATE THEN
        RAISE EXCEPTION 'Cutoff date % cannot be in the future', p_cutoff_date;
    END IF;

    OPEN cur_old;
    LOOP
        FETCH cur_old INTO rec;
        EXIT WHEN NOT FOUND;

        DELETE FROM food_prep_log WHERE CURRENT OF cur_old;   -- DML
        v_deleted := v_deleted + 1;
    END LOOP;
    CLOSE cur_old;

    RAISE NOTICE 'Archived (deleted) % preparation log(s) older than %',
                 v_deleted, p_cutoff_date;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Error during archive: %', SQLERRM;
        RAISE;   -- propagate the error to the caller
END;
$$;


ALTER PROCEDURE public.sp_archive_old_prep_logs(IN p_cutoff_date date) OWNER TO "MyUser";

--
-- Name: trg_fn_log_price_change(); Type: FUNCTION; Schema: public; Owner: MyUser
--

CREATE FUNCTION public.trg_fn_log_price_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- only act when the price really changed
    IF NEW.price IS DISTINCT FROM OLD.price THEN
        INSERT INTO menu_change_log (change_description, change_date, menu_item_id)
        VALUES (
            format('Price changed from %s to %s', OLD.price, NEW.price),
            CURRENT_TIMESTAMP,
            NEW.menu_item_id
        );
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trg_fn_log_price_change() OWNER TO "MyUser";

--
-- Name: trg_fn_maintain_times_prepared(); Type: FUNCTION; Schema: public; Owner: MyUser
--

CREATE FUNCTION public.trg_fn_maintain_times_prepared() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE menu_item
        SET    times_prepared = times_prepared + 1
        WHERE  menu_item_id = NEW.menu_item_id;
        RETURN NEW;

    ELSIF TG_OP = 'DELETE' THEN
        UPDATE menu_item
        SET    times_prepared = times_prepared - 1
        WHERE  menu_item_id = OLD.menu_item_id;
        RETURN OLD;
    END IF;

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.trg_fn_maintain_times_prepared() OWNER TO "MyUser";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chef; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.chef (
    chef_id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    specialization character varying(100),
    hire_date date NOT NULL,
    current_station_id integer,
    is_on_shift boolean DEFAULT false
);


ALTER TABLE public.chef OWNER TO "MyUser";

--
-- Name: chef_chef_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.chef ALTER COLUMN chef_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.chef_chef_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: food_prep_log; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.food_prep_log (
    log_id integer NOT NULL,
    chef_id integer NOT NULL,
    menu_item_id integer NOT NULL,
    preparation_time integer NOT NULL,
    prep_date date DEFAULT CURRENT_DATE,
    notes text
);


ALTER TABLE public.food_prep_log OWNER TO "MyUser";

--
-- Name: food_prep_log_log_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.food_prep_log ALTER COLUMN log_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.food_prep_log_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hygiene_inspection; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.hygiene_inspection (
    inspection_id integer NOT NULL,
    station_id integer NOT NULL,
    inspector_id integer NOT NULL,
    inspection_date date DEFAULT CURRENT_DATE,
    next_inspection_date date,
    cleanliness_score numeric(4,1),
    temperature_check numeric(5,2),
    status character varying(50) NOT NULL,
    comments text,
    CONSTRAINT hygiene_inspection_cleanliness_score_check CHECK (((cleanliness_score >= 1.0) AND (cleanliness_score <= 10.0))),
    CONSTRAINT hygiene_inspection_status_check CHECK (((status)::text = ANY (ARRAY[('Perfect condition'::character varying)::text, ('All clean'::character varying)::text, ('Passed inspection'::character varying)::text, ('Needs improvement'::character varying)::text, ('Fridge slightly warm'::character varying)::text, ('Good'::character varying)::text])))
);


ALTER TABLE public.hygiene_inspection OWNER TO "MyUser";

--
-- Name: hygiene_inspection_inspection_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.hygiene_inspection ALTER COLUMN inspection_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.hygiene_inspection_inspection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ingredient; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.ingredient (
    ingredient_id integer NOT NULL,
    ingredient_name character varying(100) NOT NULL,
    unit character varying(20) NOT NULL,
    CONSTRAINT check_ingredient_name CHECK ((char_length(TRIM(BOTH FROM ingredient_name)) >= 2)),
    CONSTRAINT check_unit_standard CHECK (((unit)::text = ANY ((ARRAY['kg'::character varying, 'grams'::character varying, 'ml'::character varying, 'liters'::character varying, 'pieces'::character varying, 'oz'::character varying])::text[])))
);


ALTER TABLE public.ingredient OWNER TO "MyUser";

--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.ingredient_ingredient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ingredient_ingredient_id_seq OWNER TO "MyUser";

--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.ingredient_ingredient_id_seq OWNED BY public.ingredient.ingredient_id;


--
-- Name: kitchen_order; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.kitchen_order (
    kitchen_order_id integer NOT NULL,
    order_id integer NOT NULL,
    status character varying(30) NOT NULL,
    start_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    finish_time timestamp without time zone,
    station_id integer,
    CONSTRAINT kitchen_order_status_check CHECK (((status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('In-Prep'::character varying)::text, ('Ready'::character varying)::text, ('Served'::character varying)::text, ('Cancelled'::character varying)::text])))
);


ALTER TABLE public.kitchen_order OWNER TO "MyUser";

--
-- Name: kitchen_order_kitchen_order_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.kitchen_order ALTER COLUMN kitchen_order_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.kitchen_order_kitchen_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: kitchen_station; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.kitchen_station (
    station_id integer NOT NULL,
    station_name character varying(100) NOT NULL,
    description text,
    is_active boolean DEFAULT true
);


ALTER TABLE public.kitchen_station OWNER TO "MyUser";

--
-- Name: kitchen_station_station_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.kitchen_station ALTER COLUMN station_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.kitchen_station_station_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: menu_category; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_category (
    category_id integer NOT NULL,
    category_name character varying(100) NOT NULL,
    description text,
    CONSTRAINT check_category_name CHECK ((char_length(TRIM(BOTH FROM category_name)) >= 2))
);


ALTER TABLE public.menu_category OWNER TO "MyUser";

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_category_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_category_category_id_seq OWNER TO "MyUser";

--
-- Name: menu_category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_category_category_id_seq OWNED BY public.menu_category.category_id;


--
-- Name: menu_change_log; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_change_log (
    change_id integer NOT NULL,
    change_description text,
    change_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    menu_item_id integer NOT NULL,
    CONSTRAINT check_valid_log_date CHECK ((change_date >= '2020-01-01 00:00:00'::timestamp without time zone))
);


ALTER TABLE public.menu_change_log OWNER TO "MyUser";

--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_change_log_change_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_change_log_change_id_seq OWNER TO "MyUser";

--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_change_log_change_id_seq OWNED BY public.menu_change_log.change_id;


--
-- Name: menu_item; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.menu_item (
    menu_item_id integer NOT NULL,
    item_name character varying(150) NOT NULL,
    price numeric(10,2) NOT NULL,
    description text,
    is_available boolean DEFAULT true NOT NULL,
    added_date date DEFAULT CURRENT_DATE NOT NULL,
    calories integer,
    category_id integer NOT NULL,
    times_prepared integer DEFAULT 0 NOT NULL,
    CONSTRAINT check_added_date CHECK ((added_date <= CURRENT_DATE)),
    CONSTRAINT check_calories_positive CHECK ((calories >= 0)),
    CONSTRAINT check_item_name_length CHECK ((length((item_name)::text) >= 3)),
    CONSTRAINT check_max_price CHECK ((price < (500)::numeric)),
    CONSTRAINT check_price_positive CHECK ((price > (0)::numeric)),
    CONSTRAINT chk_times_prepared_non_negative CHECK ((times_prepared >= 0))
);


ALTER TABLE public.menu_item OWNER TO "MyUser";

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.menu_item_menu_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNER TO "MyUser";

--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.menu_item_menu_item_id_seq OWNED BY public.menu_item.menu_item_id;


--
-- Name: preparation_task; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.preparation_task (
    task_id integer NOT NULL,
    kitchen_order_id integer,
    chef_id integer,
    task_description text NOT NULL,
    status character varying(50) DEFAULT 'Pending'::character varying,
    priority_level integer DEFAULT 1,
    CONSTRAINT preparation_task_priority_level_check CHECK (((priority_level >= 1) AND (priority_level <= 5)))
);


ALTER TABLE public.preparation_task OWNER TO "MyUser";

--
-- Name: preparation_task_task_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

ALTER TABLE public.preparation_task ALTER COLUMN task_id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.preparation_task_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: recipe; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.recipe (
    recipe_id integer NOT NULL,
    instructions text NOT NULL,
    menu_item_id integer NOT NULL,
    CONSTRAINT check_instructions_length CHECK ((char_length(instructions) > 10))
);


ALTER TABLE public.recipe OWNER TO "MyUser";

--
-- Name: recipe_ingredient; Type: TABLE; Schema: public; Owner: MyUser
--

CREATE TABLE public.recipe_ingredient (
    recipe_ingredient_id integer NOT NULL,
    quantity numeric(10,3) NOT NULL,
    recipe_id integer NOT NULL,
    ingredient_id integer NOT NULL,
    CONSTRAINT check_quantity_positive CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.recipe_ingredient OWNER TO "MyUser";

--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq OWNER TO "MyUser";

--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.recipe_ingredient_recipe_ingredient_id_seq OWNED BY public.recipe_ingredient.recipe_ingredient_id;


--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE; Schema: public; Owner: MyUser
--

CREATE SEQUENCE public.recipe_recipe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipe_recipe_id_seq OWNER TO "MyUser";

--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: MyUser
--

ALTER SEQUENCE public.recipe_recipe_id_seq OWNED BY public.recipe.recipe_id;


--
-- Name: v_chef_workload; Type: VIEW; Schema: public; Owner: MyUser
--

CREATE VIEW public.v_chef_workload AS
 SELECT c.chef_id,
    (((c.first_name)::text || ' '::text) || (c.last_name)::text) AS chef_name,
    c.specialization,
    ks.station_name,
    c.is_on_shift,
    count(fpl.log_id) AS total_preparations,
    round(avg(fpl.preparation_time), 1) AS avg_prep_time
   FROM ((public.chef c
     LEFT JOIN public.kitchen_station ks ON ((c.current_station_id = ks.station_id)))
     LEFT JOIN public.food_prep_log fpl ON ((fpl.chef_id = c.chef_id)))
  GROUP BY c.chef_id, c.first_name, c.last_name, c.specialization, ks.station_name, c.is_on_shift;


ALTER VIEW public.v_chef_workload OWNER TO "MyUser";

--
-- Name: v_menu_kitchen_activity; Type: VIEW; Schema: public; Owner: MyUser
--

CREATE VIEW public.v_menu_kitchen_activity AS
 SELECT mi.menu_item_id,
    mi.item_name,
    mc.category_name,
    mi.price,
    mi.is_available,
    count(fpl.log_id) AS times_prepared,
    round(avg(fpl.preparation_time), 1) AS avg_prep_time,
    max(fpl.prep_date) AS last_prepared
   FROM ((public.menu_item mi
     JOIN public.menu_category mc ON ((mi.category_id = mc.category_id)))
     LEFT JOIN public.food_prep_log fpl ON ((fpl.menu_item_id = mi.menu_item_id)))
  GROUP BY mi.menu_item_id, mi.item_name, mc.category_name, mi.price, mi.is_available;


ALTER VIEW public.v_menu_kitchen_activity OWNER TO "MyUser";

--
-- Name: ingredient ingredient_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient ALTER COLUMN ingredient_id SET DEFAULT nextval('public.ingredient_ingredient_id_seq'::regclass);


--
-- Name: menu_category category_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category ALTER COLUMN category_id SET DEFAULT nextval('public.menu_category_category_id_seq'::regclass);


--
-- Name: menu_change_log change_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log ALTER COLUMN change_id SET DEFAULT nextval('public.menu_change_log_change_id_seq'::regclass);


--
-- Name: menu_item menu_item_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item ALTER COLUMN menu_item_id SET DEFAULT nextval('public.menu_item_menu_item_id_seq'::regclass);


--
-- Name: recipe recipe_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe ALTER COLUMN recipe_id SET DEFAULT nextval('public.recipe_recipe_id_seq'::regclass);


--
-- Name: recipe_ingredient recipe_ingredient_id; Type: DEFAULT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient ALTER COLUMN recipe_ingredient_id SET DEFAULT nextval('public.recipe_ingredient_recipe_ingredient_id_seq'::regclass);


--
-- Data for Name: chef; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.chef (chef_id, first_name, last_name, specialization, hire_date, current_station_id, is_on_shift) FROM stdin;
\.
COPY public.chef (chef_id, first_name, last_name, specialization, hire_date, current_station_id, is_on_shift) FROM '$$PATH$$/3519.dat';

--
-- Data for Name: food_prep_log; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.food_prep_log (log_id, chef_id, menu_item_id, preparation_time, prep_date, notes) FROM stdin;
\.
COPY public.food_prep_log (log_id, chef_id, menu_item_id, preparation_time, prep_date, notes) FROM '$$PATH$$/3521.dat';

--
-- Data for Name: hygiene_inspection; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.hygiene_inspection (inspection_id, station_id, inspector_id, inspection_date, next_inspection_date, cleanliness_score, temperature_check, status, comments) FROM stdin;
\.
COPY public.hygiene_inspection (inspection_id, station_id, inspector_id, inspection_date, next_inspection_date, cleanliness_score, temperature_check, status, comments) FROM '$$PATH$$/3523.dat';

--
-- Data for Name: ingredient; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.ingredient (ingredient_id, ingredient_name, unit) FROM stdin;
\.
COPY public.ingredient (ingredient_id, ingredient_name, unit) FROM '$$PATH$$/3510.dat';

--
-- Data for Name: kitchen_order; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.kitchen_order (kitchen_order_id, order_id, status, start_time, finish_time, station_id) FROM stdin;
\.
COPY public.kitchen_order (kitchen_order_id, order_id, status, start_time, finish_time, station_id) FROM '$$PATH$$/3525.dat';

--
-- Data for Name: kitchen_station; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.kitchen_station (station_id, station_name, description, is_active) FROM stdin;
\.
COPY public.kitchen_station (station_id, station_name, description, is_active) FROM '$$PATH$$/3527.dat';

--
-- Data for Name: menu_category; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_category (category_id, category_name, description) FROM stdin;
\.
COPY public.menu_category (category_id, category_name, description) FROM '$$PATH$$/3508.dat';

--
-- Data for Name: menu_change_log; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_change_log (change_id, change_description, change_date, menu_item_id) FROM stdin;
\.
COPY public.menu_change_log (change_id, change_description, change_date, menu_item_id) FROM '$$PATH$$/3516.dat';

--
-- Data for Name: menu_item; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.menu_item (menu_item_id, item_name, price, description, is_available, added_date, calories, category_id, times_prepared) FROM stdin;
\.
COPY public.menu_item (menu_item_id, item_name, price, description, is_available, added_date, calories, category_id, times_prepared) FROM '$$PATH$$/3512.dat';

--
-- Data for Name: preparation_task; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.preparation_task (task_id, kitchen_order_id, chef_id, task_description, status, priority_level) FROM stdin;
\.
COPY public.preparation_task (task_id, kitchen_order_id, chef_id, task_description, status, priority_level) FROM '$$PATH$$/3529.dat';

--
-- Data for Name: recipe; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.recipe (recipe_id, instructions, menu_item_id) FROM stdin;
\.
COPY public.recipe (recipe_id, instructions, menu_item_id) FROM '$$PATH$$/3514.dat';

--
-- Data for Name: recipe_ingredient; Type: TABLE DATA; Schema: public; Owner: MyUser
--

COPY public.recipe_ingredient (recipe_ingredient_id, quantity, recipe_id, ingredient_id) FROM stdin;
\.
COPY public.recipe_ingredient (recipe_ingredient_id, quantity, recipe_id, ingredient_id) FROM '$$PATH$$/3518.dat';

--
-- Name: chef_chef_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.chef_chef_id_seq', 60, true);


--
-- Name: food_prep_log_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.food_prep_log_log_id_seq', 20011, true);


--
-- Name: hygiene_inspection_inspection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.hygiene_inspection_inspection_id_seq', 510, true);


--
-- Name: ingredient_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.ingredient_ingredient_id_seq', 502, true);


--
-- Name: kitchen_order_kitchen_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.kitchen_order_kitchen_order_id_seq', 510, true);


--
-- Name: kitchen_station_station_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.kitchen_station_station_id_seq', 15, true);


--
-- Name: menu_category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_category_category_id_seq', 500, true);


--
-- Name: menu_change_log_change_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_change_log_change_id_seq', 20007, true);


--
-- Name: menu_item_menu_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.menu_item_menu_item_id_seq', 503, true);


--
-- Name: preparation_task_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.preparation_task_task_id_seq', 20010, true);


--
-- Name: recipe_ingredient_recipe_ingredient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.recipe_ingredient_recipe_ingredient_id_seq', 20000, true);


--
-- Name: recipe_recipe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: MyUser
--

SELECT pg_catalog.setval('public.recipe_recipe_id_seq', 500, true);


--
-- Name: chef chef_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.chef
    ADD CONSTRAINT chef_pkey PRIMARY KEY (chef_id);


--
-- Name: food_prep_log food_prep_log_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.food_prep_log
    ADD CONSTRAINT food_prep_log_pkey PRIMARY KEY (log_id);


--
-- Name: hygiene_inspection hygiene_inspection_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.hygiene_inspection
    ADD CONSTRAINT hygiene_inspection_pkey PRIMARY KEY (inspection_id);


--
-- Name: ingredient ingredient_ingredient_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_ingredient_name_key UNIQUE (ingredient_name);


--
-- Name: ingredient ingredient_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.ingredient
    ADD CONSTRAINT ingredient_pkey PRIMARY KEY (ingredient_id);


--
-- Name: kitchen_order kitchen_order_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.kitchen_order
    ADD CONSTRAINT kitchen_order_pkey PRIMARY KEY (kitchen_order_id);


--
-- Name: kitchen_station kitchen_station_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.kitchen_station
    ADD CONSTRAINT kitchen_station_pkey PRIMARY KEY (station_id);


--
-- Name: menu_category menu_category_category_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_category_name_key UNIQUE (category_name);


--
-- Name: menu_category menu_category_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_category
    ADD CONSTRAINT menu_category_pkey PRIMARY KEY (category_id);


--
-- Name: menu_change_log menu_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log
    ADD CONSTRAINT menu_change_log_pkey PRIMARY KEY (change_id);


--
-- Name: menu_item menu_item_item_name_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_item_name_key UNIQUE (item_name);


--
-- Name: menu_item menu_item_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT menu_item_pkey PRIMARY KEY (menu_item_id);


--
-- Name: preparation_task preparation_task_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.preparation_task
    ADD CONSTRAINT preparation_task_pkey PRIMARY KEY (task_id);


--
-- Name: recipe_ingredient recipe_ingredient_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT recipe_ingredient_pkey PRIMARY KEY (recipe_ingredient_id);


--
-- Name: recipe recipe_menu_item_id_key; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_menu_item_id_key UNIQUE (menu_item_id);


--
-- Name: recipe recipe_pkey; Type: CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT recipe_pkey PRIMARY KEY (recipe_id);


--
-- Name: idx_food_prep_log_menu_item; Type: INDEX; Schema: public; Owner: MyUser
--

CREATE INDEX idx_food_prep_log_menu_item ON public.food_prep_log USING btree (menu_item_id);


--
-- Name: menu_item trg_log_price_change; Type: TRIGGER; Schema: public; Owner: MyUser
--

CREATE TRIGGER trg_log_price_change AFTER UPDATE ON public.menu_item FOR EACH ROW EXECUTE FUNCTION public.trg_fn_log_price_change();


--
-- Name: food_prep_log trg_maintain_times_prepared; Type: TRIGGER; Schema: public; Owner: MyUser
--

CREATE TRIGGER trg_maintain_times_prepared AFTER INSERT OR DELETE ON public.food_prep_log FOR EACH ROW EXECUTE FUNCTION public.trg_fn_maintain_times_prepared();


--
-- Name: chef chef_current_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.chef
    ADD CONSTRAINT chef_current_station_id_fkey FOREIGN KEY (current_station_id) REFERENCES public.kitchen_station(station_id);


--
-- Name: menu_item fk_category; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_item
    ADD CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES public.menu_category(category_id) ON DELETE CASCADE;


--
-- Name: food_prep_log fk_food_prep_log_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.food_prep_log
    ADD CONSTRAINT fk_food_prep_log_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id) ON DELETE CASCADE;


--
-- Name: recipe_ingredient fk_ingredient; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT fk_ingredient FOREIGN KEY (ingredient_id) REFERENCES public.ingredient(ingredient_id) ON DELETE RESTRICT;


--
-- Name: recipe fk_menu_item; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe
    ADD CONSTRAINT fk_menu_item FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id) ON DELETE CASCADE;


--
-- Name: menu_change_log fk_menu_item_log; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.menu_change_log
    ADD CONSTRAINT fk_menu_item_log FOREIGN KEY (menu_item_id) REFERENCES public.menu_item(menu_item_id) ON DELETE CASCADE;


--
-- Name: recipe_ingredient fk_recipe; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.recipe_ingredient
    ADD CONSTRAINT fk_recipe FOREIGN KEY (recipe_id) REFERENCES public.recipe(recipe_id) ON DELETE CASCADE;


--
-- Name: food_prep_log food_prep_log_chef_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.food_prep_log
    ADD CONSTRAINT food_prep_log_chef_id_fkey FOREIGN KEY (chef_id) REFERENCES public.chef(chef_id);


--
-- Name: hygiene_inspection hygiene_inspection_inspector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.hygiene_inspection
    ADD CONSTRAINT hygiene_inspection_inspector_id_fkey FOREIGN KEY (inspector_id) REFERENCES public.chef(chef_id);


--
-- Name: hygiene_inspection hygiene_inspection_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.hygiene_inspection
    ADD CONSTRAINT hygiene_inspection_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.kitchen_station(station_id);


--
-- Name: kitchen_order kitchen_order_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.kitchen_order
    ADD CONSTRAINT kitchen_order_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.kitchen_station(station_id);


--
-- Name: preparation_task preparation_task_chef_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.preparation_task
    ADD CONSTRAINT preparation_task_chef_id_fkey FOREIGN KEY (chef_id) REFERENCES public.chef(chef_id);


--
-- Name: preparation_task preparation_task_kitchen_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: MyUser
--

ALTER TABLE ONLY public.preparation_task
    ADD CONSTRAINT preparation_task_kitchen_order_id_fkey FOREIGN KEY (kitchen_order_id) REFERENCES public.kitchen_order(kitchen_order_id);


--
-- PostgreSQL database dump complete
--

